package com.myweptoonapplication

import java.io.InputStream

class Wep (val image:InputStream)