package com.myweptoonapplication

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CalendarContract
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*
import android.view.View

class MainActivity : AppCompatActivity() {
    lateinit var context:Context
    init {
        instance = this
    }
    companion object{
        private var instance: MainActivity?=null
        fun applicationContext() : Context{
            return instance!!.applicationContext
        }
    }
    private var assetList: ArrayList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        context = MainActivity.applicationContext()
        read_list()
        //img.setImageDrawable(Drawable.createFromStream(inputStream,null))

    }
    private fun read_list() {
        var assetManager:AssetManager = context.assets
        var str = assetManager.open("entry.txt").bufferedReader().use {
            it.readLine()
        }
        assetList.add(str)
        var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,assetList)
        list_item.adapter = adapter
        list_item.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val name = assetList!![position]
            val intent = Intent(this,SelectActivity::class.java)
            intent.putExtra("selected",name)
            startActivity(intent)
        }
    }
}