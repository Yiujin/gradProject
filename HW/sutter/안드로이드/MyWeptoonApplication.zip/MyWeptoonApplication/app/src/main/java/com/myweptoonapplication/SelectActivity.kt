package com.myweptoonapplication

import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.os.Bundle
import android.view.Gravity
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.list_item
import kotlinx.android.synthetic.main.select_layout.*

class SelectActivity : AppCompatActivity() {
    lateinit var context: Context
    init {
        instance = this
    }
    companion object{
        private var instance: SelectActivity?=null
        fun applicationContext() : Context {
            return instance!!.applicationContext
        }
    }
    private var assetList: ArrayList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.select_layout)
        setSupportActionBar(select_toolbar)
        val actionbar = supportActionBar!!
        actionbar.setDisplayShowTitleEnabled(false)
        actionbar.setDisplayHomeAsUpEnabled(true)
        context = SelectActivity.applicationContext()
        read_list()
        //img.setImageDrawable(Drawable.createFromStream(inputStream,null))

    }
    private fun read_list() {
        var assetManager: AssetManager = context.assets
        var top_level:String = intent.getStringExtra("selected")
        select_text.setText(top_level)
        select_text.gravity = Gravity.CENTER
        var str = assetManager.open("$top_level/select_entry.txt").bufferedReader().use {
            it.readLine()
        }
        assetList.add(str)
        var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,assetList)
        list_item.adapter = adapter
        list_item.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val entry = assetList!![position]
            val intent = Intent(this,ViewActivity::class.java)
            intent.putExtra("Top",top_level)
            intent.putExtra("selected",entry)
            startActivity(intent)
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}