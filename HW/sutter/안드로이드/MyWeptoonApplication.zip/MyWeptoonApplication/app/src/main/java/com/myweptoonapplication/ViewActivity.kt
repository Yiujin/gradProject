package com.myweptoonapplication

import android.app.ProgressDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import android.os.Bundle
import android.renderscript.ScriptGroup
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.view_layout.*
import java.io.IOException
import java.io.InputStream

class ViewActivity: AppCompatActivity() {

    lateinit var context: Context
    init {
        instance = this
    }
    companion object{
        private var instance: ViewActivity?=null
        private var set_toolbar:Boolean = false
        fun applicationContext() : Context {
            return instance!!.applicationContext
        }
        var image:RecyclerView? = null
        lateinit var tool:androidx.appcompat.widget.Toolbar
        var bottom:FrameLayout? = null
        fun set_tool(){
            if(set_toolbar == false) {
                tool.visibility = View.VISIBLE
                bottom!!.visibility = View.VISIBLE
                set_toolbar = true
            }
            else {
                tool.visibility = View.INVISIBLE
                bottom!!.visibility = View.INVISIBLE
                set_toolbar = false
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.view_layout)
        setSupportActionBar(toolbar)
        val actionbar = supportActionBar!!
        actionbar.setDisplayShowTitleEnabled(false)
        actionbar.setDisplayHomeAsUpEnabled(true)
        context = ViewActivity.applicationContext()
        image = image_view
        tool = toolbar
        bottom = bottom_menu
        Show_img(this,intent.getStringExtra("Top"),intent.getStringExtra("selected")).execute()
        tool.visibility = View.INVISIBLE
        bottom!!.visibility = View.INVISIBLE

    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
    private class Show_img(c: Context,top:String?,selected:String?): AsyncTask<Void, Void, String>() {
        private val context:Context
        private var Top_domain:String? = null
        private var Selected_entry:String? = null
        var assetManager:AssetManager? = null
        var inputStream: ArrayList<InputStream> = ArrayList()
        var wep_List = ArrayList<Wep>()
        var count:Int = 0
        lateinit var entry:String
        init {
            this.context = c
            this.Top_domain = top
            this.Selected_entry = selected
            assetManager = context.assets
        }


        override fun onPreExecute() {
            super.onPreExecute()
            entry= assetManager!!.open("${Top_domain}/${Selected_entry}/entry.txt").bufferedReader().use {
                it.readLine()
            }
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
            for( i in 0..(entry.toInt()-1)) {
                wep_List.add(Wep(inputStream[i]))
            }
            image!!.adapter = addapter(context,wep_List ) { wep ->
                set_tool()
            }
        }
        override fun doInBackground(vararg params: Void?): String? {
            try {
                while(count < entry.toInt()) {
                    inputStream.add(assetManager!!.open("${Top_domain}/${Selected_entry}/(${count+1}).jpg"))
                    count += 1
                }
                publishProgress()
            }
            catch(e: IOException) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
        }
    }
}