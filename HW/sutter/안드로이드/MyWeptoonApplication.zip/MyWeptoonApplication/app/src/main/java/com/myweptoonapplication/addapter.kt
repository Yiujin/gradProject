package com.myweptoonapplication

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.image_item.*
import kotlinx.android.synthetic.main.view_layout.*
import java.io.IOException
import java.io.InputStream


class addapter(val context: Context,val imgList : ArrayList<Wep>, val itemClick: (Wep) -> Unit): RecyclerView.Adapter<addapter.Holder>()  {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(context).inflate(R.layout.image_item, parent, false)
        return Holder(view,itemClick)
    }

    override fun getItemCount(): Int {
        return imgList.size
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(imgList[position], context)
    }
    inner class Holder(itemView: View, itemClick : (Wep) -> Unit ) : RecyclerView.ViewHolder(itemView){
        val weptoon = itemView.findViewById<ImageView>(R.id.wep_image)

        fun bind (wep : Wep,context:Context){
            weptoon!!.setImageDrawable(Drawable.createFromStream(wep.image,null))

            itemView.setOnClickListener { itemClick(wep) }
        }
    }
}